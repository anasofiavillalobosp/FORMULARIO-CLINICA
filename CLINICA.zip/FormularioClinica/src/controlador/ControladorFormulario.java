/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;
import modelo.Paciente;
import vista.VentanaFormularioDatos;
/**
 *
 * @author Estudiantes
 */
public class ControladorFormulario {
    private VentanaFormularioDatos vista;

    public ControladorFormulario() {
        vista = new VentanaFormularioDatos();
        configurarEventos();

    }

    public void iniciar() {
        vista.setVisible(true);
    }

  private void configurarEventos() {

        vista.getBtnGuardar().addActionListener(e -> registrarPaciente());

        vista.getBtnCancelar().addActionListener(e -> vista.limpiarFormulario());

        vista.getBtnInicio().addActionListener(e -> mostrarSeccion("Inicio"));

        vista.getBtnPacientes().addActionListener(e -> mostrarSeccion("Pacientes"));

        vista.getBtnMuestras().addActionListener(e -> mostrarSeccion("Toma de muestras"));

        vista.getBtnResultados().addActionListener(e -> mostrarSeccion("Resultados"));

        vista.getBtnReportes().addActionListener(e -> mostrarSeccion("Reportes"));

        vista.getBtnConfiguracion().addActionListener(e -> mostrarSeccion("Configuración"));
    }

    private void registrarPaciente() {       
        String tipoDocumento = vista.getTipoDocumento();
        String documento = vista.getDocumento();
        String nombres = vista.getNombres();
        String apellidos = vista.getApellidos();

        if (documento.isEmpty() || nombres.isEmpty() || apellidos.isEmpty()) {
            vista.mostrarMensaje("Complete los datos principales.");
            return;
        }

        Paciente paciente = new Paciente(tipoDocumento,documento, nombres, apellidos);

        vista.mostrarMensaje( "Paciente creado correctamente."  + "Nombre: " + paciente.getNombres() + " " + paciente.getApellidos() + "\nDocumento: " + paciente.getDocumento()
        );
    }

    private void mostrarSeccion(String seccion) {
        vista.mostrarMensaje("Sección " + seccion);
    }

}


