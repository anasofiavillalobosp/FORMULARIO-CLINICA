/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 *
 * @author Estudiantes
 */
public class VentanaFormularioDatos extends JFrame {
    
    private JTextField txtDocumento, txtNombres, txtApellidos;

    private JButton btnGuardar, btnCancelar;
    private JButton btnInicio, btnPacientes, btnMuestras;
    private JButton btnResultados, btnReportes, btnConfiguracion;
    private JComboBox<String> tipoDocumento;

    public VentanaFormularioDatos() {

        setTitle("Sistema de Clinica");
        setSize(850, 550);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Encabezado
        JLabel titulo = new JLabel("   SISTEMA DE CLINICA");
        titulo.setFont(new Font("Arial", Font.BOLD, 22));
        titulo.setForeground(Color.WHITE);
        titulo.setBackground(new Color(25, 55, 100));
        titulo.setOpaque(true);
        titulo.setPreferredSize(new Dimension(0, 65));

        add(titulo, BorderLayout.NORTH);

        // Menú lateral
        JPanel menu = new JPanel(new GridLayout(6, 1, 5, 5));
        menu.setBackground(new Color(20, 45, 80));
        menu.setPreferredSize(new Dimension(170, 0));

        btnInicio = crearBoton("Inicio");
        btnPacientes = crearBoton("Pacientes");
        btnMuestras = crearBoton("Toma de muestras");
        btnResultados = crearBoton("Resultados");
        btnReportes = crearBoton("Reportes");
        btnConfiguracion = crearBoton("Configuración");

        menu.add(btnInicio);
        menu.add(btnPacientes);
        menu.add(btnMuestras);
        menu.add(btnResultados);
        menu.add(btnReportes);
        menu.add(btnConfiguracion);

        add(menu, BorderLayout.WEST);

        // Panel principal 
        JPanel principal = new JPanel(new BorderLayout(10, 15));
        principal.setBackground(new Color(245, 248, 252));
        principal.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel subtitulo = new JLabel("Registrar paciente");
        subtitulo.setFont(new Font("Arial", Font.BOLD, 22));
        subtitulo.setForeground(new Color(25, 55, 100));

        principal.add(subtitulo, BorderLayout.NORTH);

        // Crear el estilo de mi formulario
        JPanel formulario = new JPanel(new GridLayout(0, 2, 12, 15));
        formulario.setBackground(Color.WHITE);
        formulario.setBorder(  BorderFactory.createEmptyBorder(20, 20, 20, 20) );

        txtDocumento = new JTextField();
        txtNombres = new JTextField();
        txtApellidos = new JTextField();
        
        formulario.add(new JLabel("Tipo de Documento: "));
        formulario.add ( new JComboBox<>(new String[]{ "Cedula de ciudadanía", "Tarjeta de identidad", "Cedula de extranjería",  "Pasaporte"}));

        formulario.add(new JLabel("Numero de documento:"));
        formulario.add(txtDocumento);

        formulario.add(new JLabel("Nombres:"));
        formulario.add(txtNombres);

        formulario.add(new JLabel("Apellidos:"));
        formulario.add(txtApellidos);

        formulario.add(new JLabel("Fecha de nacimiento:"));
        formulario.add(new JTextField());

        formulario.add(new JLabel("Genero:"));
        formulario.add(new JComboBox<>( new String[]{"Masculino", "Femenino", "Otro"}));

        formulario.add(new JLabel("Telefono:"));
        formulario.add(new JTextField());

        formulario.add(new JLabel("Correo electronico:"));
        formulario.add(new JTextField());

        formulario.add(new JLabel("Direccion:"));
        formulario.add(new JTextField());

        formulario.add(new JLabel("EPS:"));
        formulario.add(new JComboBox<>(
            new String[]{"Nueva EPS", "Sanitas", "Sura", "Otra"}
        ));

        formulario.add(new JLabel("Régimen:"));
        formulario.add(new JComboBox<>(
            new String[]{"Contributivo", "Subsidiado"}
        ));

        principal.add(formulario, BorderLayout.CENTER);

        // Botones inferiores
        JPanel panelBotones = new JPanel( new FlowLayout(FlowLayout.RIGHT));
        panelBotones.setBackground(new Color(245, 248, 252));

        btnCancelar = new JButton("Cancelar");
        btnGuardar = new JButton("Guardar paciente");

        btnGuardar.setBackground(new Color(35, 105, 195));
        btnGuardar.setForeground(Color.WHITE);

        panelBotones.add(btnCancelar);
        panelBotones.add(btnGuardar);

        principal.add(panelBotones, BorderLayout.SOUTH);

        add(principal, BorderLayout.CENTER);
    }
// un molde para los estilos y los botones
    private JButton crearBoton(String texto) {
        JButton boton = new JButton(texto);
        boton.setForeground(Color.WHITE);
        boton.setBackground(new Color(20, 45, 80));
        boton.setFocusPainted(false);
        boton.setHorizontalAlignment(SwingConstants.LEFT);
        return boton;
    }
    public String getTipoDocumento() {
    return (String) tipoDocumento.getSelectedItem();
    }
    
    public String getDocumento() {
        return txtDocumento.getText().trim();
    }

    public String getNombres() {
        return txtNombres.getText().trim();
    }

    public String getApellidos() {
        return txtApellidos.getText().trim();
    }

    // Limpiar los campos principales
    public void limpiarFormulario() {
        txtDocumento.setText("");
        txtNombres.setText("");
        txtApellidos.setText("");
    }

    // Botones para el controlador
    public JButton getBtnGuardar() { return btnGuardar; }
    public JButton getBtnCancelar() { return btnCancelar; }
    public JButton getBtnInicio() { return btnInicio; }
    public JButton getBtnPacientes() { return btnPacientes; }
    public JButton getBtnMuestras() { return btnMuestras; }
    public JButton getBtnResultados() { return btnResultados; }
    public JButton getBtnReportes() { return btnReportes; }
    public JButton getBtnConfiguracion() { return btnConfiguracion; }

    public void mostrarMensaje(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje);
    }
}


